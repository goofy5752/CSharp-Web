﻿namespace CarShop.ViewModels.Issues
{
    public class CreateIssueInputModel
    {
        public string Description { get; set; }
    }
}
