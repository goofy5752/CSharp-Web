﻿namespace CarShop.ViewModels.Users
{
    public class LoginInputModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
