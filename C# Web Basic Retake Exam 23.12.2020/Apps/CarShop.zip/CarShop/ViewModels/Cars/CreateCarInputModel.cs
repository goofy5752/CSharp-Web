﻿namespace CarShop.ViewModels.Cars
{
    public class CreateCarInputModel
    {
        public string Model { get; set; }

        public int Year { get; set; }

        public string Image { get; set; }

        public string PlateNumber { get; set; }

        public string OwnerId { get; set; }
    }
}
