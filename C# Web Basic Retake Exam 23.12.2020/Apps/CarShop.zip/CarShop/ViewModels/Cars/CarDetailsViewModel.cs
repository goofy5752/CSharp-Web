﻿namespace CarShop.ViewModels.Cars
{
    public class CarDetailsViewModel
    {
    }
}
